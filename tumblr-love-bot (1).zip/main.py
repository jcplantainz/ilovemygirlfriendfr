import pytumblr
import schedule
import time
import json
import os
from datetime import datetime
from keep_alive import keep_alive

keep_alive()  # Optional: If running with uptime pings

# Constants
POST_FILE = "post_count.json"
ANNIVERSARY_START_YEAR = 2022
ANNIVERSARY_MONTH = 9
ANNIVERSARY_DAY = 21

# Tumblr API client
client = pytumblr.TumblrRestClient(
    os.environ['TUMBLR_CONSUMER_KEY'],
    os.environ['TUMBLR_CONSUMER_SECRET'],
    os.environ['TUMBLR_OAUTH_TOKEN'],
    os.environ['TUMBLR_OAUTH_SECRET']
)

BLOG_NAME = os.environ['TUMBLR_BLOG_NAME']

# Day tracking
def get_day_count():
    if os.path.exists(POST_FILE):
        with open(POST_FILE, 'r') as f:
            return json.load(f).get("count", 1)
    return 1

def save_day_count(count):
    with open(POST_FILE, 'w') as f:
        json.dump({"count": count}, f)

# Anniversary logic
def is_anniversary_today():
    today = datetime.now()
    return today.month == ANNIVERSARY_MONTH and today.day == ANNIVERSARY_DAY

def get_anniversary_year():
    return datetime.now().year - ANNIVERSARY_START_YEAR + 1

# Post logic
def post_love_message():
    day = get_day_count()
    message = f"Day {day} of telling y’all I love my girlfriend @chescheschronicles unconditionally 💖"

    if is_anniversary_today():
        years = get_anniversary_year()
        message += f" and it’s our {years} year anniversary 💍"

    client.create_text(BLOG_NAME, state="published", body=message)
    print(f"Posted: {message}")
    save_day_count(day + 1)

# Schedule
schedule.every().day.at("09:00").do(post_love_message)

print("Tumblr Love Bot is running...")
while True:
    schedule.run_pending()
    time.sleep(60)