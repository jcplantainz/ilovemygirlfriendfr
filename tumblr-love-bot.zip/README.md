# Tumblr Love Bot ❤️

This is a Python bot that posts a daily message to your Tumblr blog.

## 💬 Message Format

- Normal Day:  
  `Day X of telling y’all I love my girlfriend @chescheschronicles unconditionally 💖`

- On Anniversary (Sept 21):  
  `...and it's our X year anniversary 💍`

## 🛠 Setup

1. Clone this repository
2. Run `pip install -r requirements.txt`
3. Create a `.env` file based on `.env.example` and add your Tumblr API keys
4. Run `python main.py`

## 🌱 Keep It Running (Optional)

Use [UptimeRobot](https://uptimerobot.com/) to ping the Flask `keep_alive` endpoint for free 24/7 hosting.

---